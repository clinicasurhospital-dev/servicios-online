<?php

require_once __DIR__ . '/../vendor/autoload.php';

$testClasses = [
    'Tests\Unit\AvailabilityTest',
    'Tests\Feature\AuthenticationTest',
    'Tests\Feature\AuthorizationTest',
    'Tests\Feature\AppointmentTest',
    'Tests\Feature\ConcurrentBookingTest',
    'Tests\Feature\ReschedulingTest',
    'Tests\Feature\CancellationTest',
    'Tests\Feature\PaymentTest',
    'Tests\Feature\PatientAccessTest',
    'Tests\Feature\DoctorAccessTest',
];

if (!empty($argv[1])) {
    $testClasses = [$argv[1]];
}

$outputFile = __DIR__ . '/test_output.txt';
file_put_contents($outputFile, "Test execution started at " . date('Y-m-d H:i:s') . "\n\n");

function logOut($str) {
    global $outputFile;
    file_put_contents($outputFile, $str . "\n", FILE_APPEND);
    echo $str . "\n";
}

$passed = 0;
$failed = 0;

foreach ($testClasses as $testClass) {
    if (!class_exists($testClass)) {
        logOut("Class $testClass not found.");
        continue;
    }
    
    $reflection = new ReflectionClass($testClass);
    $methods = array_filter(
        $reflection->getMethods(ReflectionMethod::IS_PUBLIC),
        fn($m) => str_starts_with($m->getName(), 'test_')
    );

    logOut("\n=== Testing $testClass (" . count($methods) . " tests) ===");

    foreach ($methods as $method) {
        $methodName = $method->getName();
        $test = new $testClass($methodName);
        
        try {
            $test->runBare();
            logOut("  [PASS] $methodName");
            $passed++;
        } catch (\PHPUnit\Framework\ExpectationFailedException $e) {
            logOut("  [FAIL - ASSERTION] $methodName");
            logOut("    Message: " . $e->getMessage());
            logOut("    At: " . $e->getFile() . ":" . $e->getLine());
            if (property_exists($test, 'response') && $test->response) {
                try {
                    logOut("    Response Status: " . $test->response->status());
                    if ($test->response->exception) {
                        logOut("    Server Exception: " . $test->response->exception->getMessage());
                        logOut("    Server Trace: " . substr($test->response->exception->getTraceAsString(), 0, 400));
                    }
                } catch (\Throwable $ignored) {}
            }
            $failed++;
        } catch (\Throwable $e) {
            logOut("  [FAIL - EXCEPTION] $methodName (" . get_class($e) . ")");
            logOut("    Message: " . $e->getMessage());
            logOut("    At: " . $e->getFile() . ":" . $e->getLine());
            logOut("    Trace: " . substr($e->getTraceAsString(), 0, 500));
            $failed++;
        }
    }
}

logOut("\n========================================");
logOut("SUMMARY: Total: " . ($passed + $failed) . " | Passed: $passed | Failed: $failed");
logOut("========================================");
