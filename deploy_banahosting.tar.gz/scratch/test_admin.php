<?php

require_once __DIR__ . '/../vendor/autoload.php';
$app = require __DIR__ . '/../bootstrap/app.php';
$kernel = $app->make(\Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

\Illuminate\Support\Facades\Artisan::call('migrate', ['--database' => 'testing', '--force' => true]);
\Illuminate\Support\Facades\Artisan::call('db:seed', ['--class' => 'RoleAndPermissionSeeder', '--database' => 'testing']);

$user = \App\Models\User::create([
    'name' => 'Admin Test',
    'email' => 'admintest@test.com',
    'password' => bcrypt('password'),
    'is_active' => true,
]);
$user->assignRole('ADMIN');
\Illuminate\Support\Facades\Auth::login($user);

try {
    $controller = $app->make(\App\Http\Controllers\Admin\AdminDashboardController::class);
    $view = $controller->index();
    $rendered = $view->render();
    echo "SUCCESS: Rendered admin dashboard! Length: " . strlen($rendered) . "\n";
} catch (\Throwable $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "AT: " . $e->getFile() . ":" . $e->getLine() . "\n";
    echo "TRACE:\n" . $e->getTraceAsString() . "\n";
}
