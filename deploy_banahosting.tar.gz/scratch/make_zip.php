<?php

$zip = new ZipArchive();
if ($zip->open(__DIR__ . '/../deploy_banahosting.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
    $baseDir = realpath(__DIR__ . '/..');
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($baseDir, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::LEAVES_ONLY
    );
    
    $whitelist = ['app', 'bootstrap', 'config', 'database', 'public', 'resources', 'routes', 'storage', 'vendor'];
    $singleFiles = ['artisan', 'composer.json', 'composer.lock', '.env.example'];

    $count = 0;
    foreach ($files as $name => $file) {
        if (!$file->isDir()) {
            $filePath = $file->getRealPath();
            $relativePath = substr($filePath, strlen($baseDir) + 1);
            $relativePath = str_replace('\\', '/', $relativePath);
            
            $firstSegment = explode('/', $relativePath)[0];
            if (in_array($firstSegment, $whitelist) || in_array($relativePath, $singleFiles)) {
                if (str_starts_with($relativePath, 'storage/logs/') && $relativePath !== 'storage/logs/.gitignore') continue;
                if (str_starts_with($relativePath, 'storage/framework/sessions/') && $relativePath !== 'storage/framework/sessions/.gitignore') continue;
                if (str_starts_with($relativePath, 'storage/framework/views/') && $relativePath !== 'storage/framework/views/.gitignore') continue;
                if (str_starts_with($relativePath, 'storage/framework/cache/data/')) continue;
                
                $zip->addFile($filePath, $relativePath);
                $count++;
            }
        }
    }
    $zip->close();
    echo "deploy_banahosting.zip created successfully with $count files! Size: " . round(filesize(__DIR__ . '/../deploy_banahosting.zip') / 1024 / 1024, 2) . " MB\n";
} else {
    echo "Failed to create zip file.\n";
}
