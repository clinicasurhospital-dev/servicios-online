<?php
ob_implicit_flush(true);
echo "1. Starting\n";
require __DIR__ . '/../vendor/autoload.php';
echo "2. Autoload done\n";
$app = require __DIR__ . '/../bootstrap/app.php';
echo "3. App created: " . get_class($app) . "\n";
echo "4. Environment: " . $app->environment() . "\n";
