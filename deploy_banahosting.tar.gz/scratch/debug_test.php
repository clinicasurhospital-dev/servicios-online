<?php

require_once __DIR__ . '/../vendor/autoload.php';
$app = require __DIR__ . '/../bootstrap/app.php';
$kernel = $app->make(\Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$test = new \Tests\Feature\DoctorAccessTest('test_doctor_sees_only_own_appointments_in_agenda');
$test->setUp();

try {
    $test->withoutExceptionHandling();
    $test->test_doctor_sees_only_own_appointments_in_agenda();
    echo "PASS\n";
} catch (\Throwable $e) {
    echo "FAIL: " . get_class($e) . "\n";
    echo "Message: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . ":" . $e->getLine() . "\n";
    echo "Trace:\n" . substr($e->getTraceAsString(), 0, 800) . "\n";
}
