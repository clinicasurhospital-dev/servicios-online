<?php

require_once __DIR__ . '/../vendor/autoload.php';

$args = array_slice($argv, 1);
if (empty($args)) {
    $args = ['tests'];
}

$cliArgs = array_merge(['phpunit', '--colors=never', '--no-coverage'], $args);
$application = new \PHPUnit\TextUI\Application();
$exitCode = $application->run($cliArgs);
exit($exitCode);
